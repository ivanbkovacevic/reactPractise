import React, { Component } from 'react';


class Four extends Component {
  render(){
    return(
      <div>
        <h1>I am Four.1 component</h1>

      </div>
    );
  }
}

export default Four;
