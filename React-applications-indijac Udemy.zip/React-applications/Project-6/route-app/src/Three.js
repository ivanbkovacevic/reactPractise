import React, { Component } from 'react';

class Three extends Component {
  render(){
    return(
      <div>
        <h1>I am Three component</h1>
      </div>
    );
  }
}

export default Three;
