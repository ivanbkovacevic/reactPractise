import React, { Component } from 'react';

class Two extends Component {
  render(){
    return(
      <div>
        <h1>I am Two component</h1>
      </div>
    );
  }
}

export default Two;
